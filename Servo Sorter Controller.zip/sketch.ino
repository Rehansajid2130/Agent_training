#include <Servo.h>

const int buttonPin = 2;
const int colorSwitchPin = 3;
const int servoPin = 9;

Servo gate;
bool buttonWasPressed = false;

void setup() {
  Serial.begin(9600);
  pinMode(buttonPin, INPUT_PULLUP);
  pinMode(colorSwitchPin, INPUT);

  gate.attach(servoPin);
  gate.write(90);
}

void loop() {
  bool buttonPressed = digitalRead(buttonPin) == LOW;

  // Sort once when the button changes from released to pressed.
  if (buttonPressed && !buttonWasPressed) {
    bool isRed = digitalRead(colorSwitchPin) == LOW;

    if (isRed) {
      gate.write(45);
      Serial.println("Red item -> left bin");
    } else {
      gate.write(135);
      Serial.println("Blue item -> right bin");
    }

    delay(800);
    gate.write(90);
    Serial.println("Return to center commanded");
  }

  buttonWasPressed = buttonPressed;
  delay(25);
}